/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Connect.DB_Connection;
import java.sql.CallableStatement;
import java.sql.Connection;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.internal.OracleTypes;
import static Controllers.Controller_Main.connect;
/**
 *
 * @author Jonathan
 */
public class Controller_Shcart_appuserxclock {
    public Controller_Shcart_appuserxclock(){
            if (connect==null){//creates the connection to the database
            connect=(Connection) new DB_Connection().obtainConnection();
        }
    }
    
        
    public String create(String idUser,int idClock){
        try{
            CallableStatement cstmt = connect.prepareCall("{ ? = call packagefnnew.fnNewShCart_appuserxclock(?,?)}");
            cstmt.setString(2, idUser);
            cstmt.setInt(3, idClock);
            cstmt.registerOutParameter(1, OracleTypes.VARCHAR);
            cstmt.execute();
            String result;
            result = ((OracleCallableStatement)cstmt).getString(1);
            System.out.println(result);
            return result;
        } catch(Exception e){
        return "Wrong data, was not created";
        }
    }
     
}
