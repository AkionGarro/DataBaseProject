/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package windowCreateCondition;

import Connect.DB_Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.CallableStatement;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.internal.OracleTypes;
import java.sql.ResultSet;
/**
 *
 * @author Jonathan
 */
public class Controller_Condition {
    public static Connection connect=null;//sets the connection to the database
    public  Controller_Condition(){
        if (connect==null){//creates the connection to the database
            connect=(Connection) new DB_Connection().obtainConnection();
        }
    }
    //returns array with the list of conditions from database sysrefcursor
    public DefaultTableModel listCondition(){
        try{
            DefaultTableModel table=new DefaultTableModel();

            table.addColumn("ID");

            table.addColumn("Name");

            table.addColumn("Description");
            //calls function that returns the list
            CallableStatement cstmt= connect.prepareCall("{ ? = call fnListConditionBasic}");

            cstmt.registerOutParameter(1, OracleTypes.CURSOR);

            cstmt.execute();

            ResultSet rs=((OracleCallableStatement)cstmt).getCursor(1);
            
            String data[]= new  String[3];
            
            while(rs.next()){
                data[0]=String.valueOf(rs.getInt("idCondition"));
                data[1]=rs.getString("nameCondition");
                data[2]=rs.getString("descriptionC");
                table.addRow(data);
            }
            return table;
        }catch(Exception e){
            return null;
        }
    }
    //Function that calls function fnNewCondition in the database
    public boolean createCondition(String nameC, String descriptionC){
        try{
            CallableStatement cstmt = connect.prepareCall("{ ? = call fnNewCondition(?,?)}");
            cstmt.setString(2, nameC);
            cstmt.setString(3, descriptionC);
            cstmt.registerOutParameter(1, OracleTypes.VARCHAR);//calls the function that returns a 1 if it was created or 0 it it was not
            cstmt.execute();
            
            String result;
            result = ((OracleCallableStatement)cstmt).getString(1);
            System.out.println(result);
            if (result.equals("1"))//if the tuple was created
                return true;
            return false;
        } catch(Exception e){
        return false;
        }
    }
    
}

